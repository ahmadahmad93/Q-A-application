<?php
include './header.php';
?>
        <section>
<?php
include './main_content.php';
?>
        </section>
 <?php
include './footer.php';
?>     